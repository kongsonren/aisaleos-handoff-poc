# 墨子 V0.1 RC1 运行依赖闭包报告（Builder v4 定稿）

## 结论
- RUNTIME_DEPENDENCY_CLOSURE = PASS
- 10 个代码组件字节与 v3 已审完全一致（builder 提取自 v3 zip 并断言 SHA）。
- 8 项运行依赖在 v3 manifest 已声明角色与验证规则。

## 代码组件清单（10）
- `src/mozi.py`  4464 B  `1e4bddf37476a347e5bbe3b38d45baf6ff264b5b9d57f73c1aa1257a61e8477f`
- `src/compiler.py`  10263 B  `2004c318ca316e32c5f7c9fc368b0861eaecfe152a803b50efa59a6ba0bef402`
- `src/contract.py`  1222 B  `f67b8bd79e5e6eafba58e85b0c92fcae95608a37eeca2491bbb2d1542a6c7d80`
- `src/executor.py`  3055 B  `16d5a18d748d651dd1d7f9868de8f95db0291d4523195f1c2be297d30623a814`
- `src/result_gate.py`  22578 B  `81c5b13acc6a9ebe41084ae992dd7d040e8ec3c3b79090d08a348ec9c9603ed0`
- `src/ledger.py`  3859 B  `c05e6e812db24b0539b0af53f5c3ac45fa28bc3d2131457da1e44a80add2b8b9`
- `wb1_local_exec_bridge.py`  25599 B  `587eca1e543e8ed3a3466e259e2e4189199a2ff749531b16f1868500d46204fb`
- `wb1_case002_nas.py`  6574 B  `ab241239148b4f3af2bfba1e8155bae9d092d52503a5b442f39a3c96ebaf0be0`
- `wb1_case002_trace.py`  3577 B  `2d13faefbc9964aa4959fe786f8fdf14ce7760aa2ba2fabaa66c62c403065814`

## 配置/数据/运行态依赖（8，沿用 v3 声明）
- `router_rules.json`  role=CONFIG_MUTABLE  rule=File MUST exist & be valid JSON at runtime. MUTABLE by design (PATCH_OWN_ROUTER writes it); declared SHA is a baseline snapshot, not a freeze. Absence -> PATCH_OWN_ROUTER & NAS_ARCHIVE data-driven rules FAIL.
- `MOZI_SIGNING_KEY`  role=RUNTIME_PARAM  rule=MUST be present at execution time (exported into process env). NEVER written to disk / ZIP / Ledger / Evidence. Absence -> COMMAND_GATE rejects.
- `github_pat`  role=CONFIG_PROTECTED  rule=Bridge DENY_SUBSTR includes 'github_pat' -> bridge MUST NOT write any file whose path contains it. Bridge does NOT read it. Absence is acceptable (no GitHub ops in scope).
- `.lark-cli`  role=CONFIG_PROTECTED  rule=Bridge DENY_SUBSTR includes '.lark-cli' -> bridge MUST NOT write under it. Not read by RC1 in-scope actions.
- `NAS_ROOT`  role=DATA_STORE  rule=Reachable + writable at execution; guard_archive_root(NAS_ROOT) enforces identity (no local-name fallback). Absence -> NAS_ARCHIVE STOP.
- `WB1`  role=RUNTIME_STATE_DIR  rule=MUST exist & be writable. Hosts router_rules.json, exec_results/, exec_bridge_ledger.json, github_pat.
- `exec_results`  role=RUNTIME_STATE_DIR  rule=MUST be writable; auto-created if absent.
- `exec_bridge_ledger.json`  role=RUNTIME_STATE_FILE  rule=Writable; auto-created if absent. Not a frozen artifact; runtime-mutated.

## 打包纪律（本版修复）
- 全新 staging，禁止复用；显式 allowlist；Manifest SHA 从写盘字节重算；
- Transport Receipt 放包外（ZIP_SHA+SIZE+entry_count+Manifest_SHA），消除自引用；
- 包内无 receipt/hash 文件，STALE_ARTIFACT_METADATA=0。
