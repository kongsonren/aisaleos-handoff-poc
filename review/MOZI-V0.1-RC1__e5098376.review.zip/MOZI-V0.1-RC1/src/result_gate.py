#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨子 V0.1 · Result Gate（验）— R1
==================================
核心纪律（需求书第五节 + R1-③④）：
哪吒返回 RESULT=PASS 不能直接 CLOSED。必须同时满足：
  RESULT + EVIDENCE + ASSERTION PASS -> CLOSED，否则保持 OPEN 并进入异常态。

③ Baseline Assertions 单一真源：assertion 列表以 contract_v0.1.json 为唯一来源；
   result_gate 只实现合同列出的 id，缺失实现 -> UNSUPPORTED_ASSERTION FAIL（不跳过/不默认PASS）。
   EXTRA_ASSERTIONS 只能引用已注册 id（加严），未知 id -> UNSUPPORTED_ASSERTION。
④ 独立核验证据：对 READ_FILE / READBACK_HASH，Result Gate 独立读取真实目标并重算 SHA256，
   与 executor 自报声明比对；机器自报 PASS 不能成为 CLOSED 依据。
"""
import os
import json
import hashlib
import datetime

VERDICT_CLOSED = "CLOSED"
VERDICT_OPEN = "OPEN"


def _now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _open(reason, **detail):
    return {"VERDICT": VERDICT_OPEN, "REASON": reason, "DETAIL": detail}


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ---------- Assertion 实现（与 contract_v0.1.json 的 id 一一对应）----------
# 每个函数接收 exec_result，返回 (ok, why)。实现必须至少与合同 rule 同等严格。
def _a_pass_stop(r):
    if r.get("RESULT") not in ("PASS", "STOP"):
        return False, f"RESULT={r.get('RESULT')} not in PASS/STOP"
    return True, "ok"


def _a_read_pass_evidence(r):
    if r.get("RESULT") == "PASS":
        if not r.get("AFTER_SHA256"):
            return False, "AFTER_SHA256 empty on PASS"
        if not isinstance(r.get("SIZE"), int) or r["SIZE"] < 0:
            return False, "SIZE invalid"
    return True, "ok"


def _a_read_stop_blocker(r):
    if r.get("RESULT") == "STOP":
        allowed = ["FILE_NOT_FOUND", "TARGET_PATH_UNAVAILABLE",
                   "DENY_PATH(secret-pattern)", "DENY_PATH(outside read roots)"]
        if r.get("BLOCKER") not in allowed:
            return False, "STOP BLOCKER not in allowed list"
    return True, "ok"


def _a_kr_relay_zero(r):
    if r.get("KR_RELAY") != 0:
        return False, f"KR_RELAY={r.get('KR_RELAY')} != 0"
    return True, "ok"


def _a_patch_target(r):
    if r.get("RESULT") == "PASS" and r.get("TARGET_NORMALIZED") != "ROUTER_RULES":
        return False, "TARGET not normalized to ROUTER_RULES"
    return True, "ok"


def _a_patch_keys(r):
    if r.get("RESULT") == "PASS":
        keys = r.get("CHANGES_KEYS") or []
        allowed = r.get("PATCHABLE_KEYS") or []
        if not set(keys).issubset(set(allowed)):
            return False, "changes keys not subset of patchable_keys"
    return True, "ok"


def _a_patch_pass_evidence(r):
    if r.get("RESULT") == "PASS":
        for f in ("BEFORE_SHA256", "AFTER_SHA256", "DIFF", "APPLIED"):
            if not r.get(f):
                return False, f"{f} empty on PASS"
    return True, "ok"


def _a_patch_no_py_modified(r):
    if r.get("RESULT") == "PASS" and r.get("PYTHON_MODIFIED") is True:
        return False, "Python source modified"
    return True, "ok"


def _a_nas_result(r):
    if r.get("RESULT") not in ("PASS", "STOP", "FAIL"):
        return False, f"RESULT={r.get('RESULT')}"
    return True, "ok"


def _a_nas_pass(r):
    if r.get("RESULT") == "PASS":
        if not r.get("NAS_PATH"):
            return False, "NAS_PATH missing on PASS"
        if r.get("READBACK") != "PASS":
            return False, "READBACK != PASS"
    return True, "ok"


def _a_nas_fail_blocker(r):
    if r.get("RESULT") == "FAIL":
        if r.get("BLOCKER") not in ("READBACK_MISMATCH", "MANIFEST_REGISTER_FAILED", "ARCHIVE_WRITE_FAILED"):
            return False, "FAIL BLOCKER not allowed"
    return True, "ok"


def _a_nas_stop_blocker(r):
    if r.get("RESULT") == "STOP":
        if r.get("BLOCKER") not in ("RAW_SOURCE_UNAVAILABLE", "INLINE_DOC_PARSE_FAILED",
                                     "PATH_GUARD", "NO_DOC_ARCHIVED"):
            return False, "STOP BLOCKER not allowed"
    return True, "ok"


def _a_nas_no_overwrite(r):
    if r.get("RESULT") == "PASS" and r.get("OVERWROTE_HISTORY") is True:
        return False, "overwrote historical RAW"
    return True, "ok"


def _a_reprocess_result(r):
    if not r.get("RESULT"):
        return False, "no RESULT"
    return True, "ok"


def _a_reprocess_source(r):
    if r.get("SOURCE_COMMENT_ID") and r.get("TARGET") and \
       str(r["SOURCE_COMMENT_ID"]) != str(r["TARGET"]):
        return False, "SOURCE_COMMENT_ID != TARGET"
    return True, "ok"


def _a_reprocess_receipts(r):
    if r.get("RESULT") == "PASS" and r.get("NEW_RECEIPTS") is True:
        if not r.get("ACK_COMMENT_ID") and not r.get("RESULT_COMMENT_ID"):
            return False, "no receipts on new emit"
    return True, "ok"


def _a_gov_result(r):
    if r.get("RESULT") not in ("PASS", "FAIL"):
        return False, f"RESULT={r.get('RESULT')}"
    return True, "ok"


def _a_gov_pass(r):
    if r.get("RESULT") == "PASS":
        if not r.get("AFTER_SHA256"):
            return False, "AFTER_SHA256 missing"
        if r.get("EVIDENCE_PATH") != r.get("GOVERNANCE_PATH"):
            return False, "EVIDENCE_PATH != GOV_DOC_PATH"
    return True, "ok"


def _a_relay_pass(r):
    if r.get("RESULT") != "PASS":
        return False, f"RESULT={r.get('RESULT')}"
    if not r.get("RELAY_ACK_COMMENT_ID"):
        return False, "RELAY_ACK_COMMENT_ID missing"
    return True, "ok"


def _a_mozi_result(r):
    if r.get("RESULT") not in ("VERIFIED_READBACK_PASS", "UNKNOWN"):
        return False, f"RESULT={r.get('RESULT')}"
    return True, "ok"


def _a_mozi_pass(r):
    if r.get("RESULT") == "VERIFIED_READBACK_PASS":
        if r.get("REPO_READBACK") != "PASS" or r.get("COMMIT_READBACK") != "PASS":
            return False, "repo/commit readback not PASS"
        if "=200" not in (r.get("FILE_READBACK") or ""):
            return False, "FILE_READBACK lacks 200"
    return True, "ok"


def _a_mozi_no_action(r):
    if r.get("RESULT") == "VERIFIED_READBACK_PASS":
        if r.get("NO_ACTION_TAKEN") != "TRUE":
            return False, "side effect detected (NO_ACTION_TAKEN != TRUE)"
    return True, "ok"


# 注册表：合同 baseline_assertions 列出的每个 id 必须在此有实现，否则 UNSUPPORTED_ASSERTION。
def _a_ext_probe(r):
    """R2-② 测试钩子：仅可通过 EXTRA_ASSERTIONS 引用（不出现在任何 ACTION baseline 中）。
    用于证明 extra assertion 经由 Signed Command 真实执行：EXTRA_PROBE 必须等于 EXPECTED_VALUE。"""
    if r.get("EXTRA_PROBE") != "EXPECTED_VALUE":
        return False, "EXTRA_PROBE != EXPECTED_VALUE"
    return True, "ok"


ASSERTION_IMPL = {
    "RDF#A1": _a_pass_stop, "RDF#A2": _a_read_pass_evidence,
    "RDF#A3": _a_read_stop_blocker, "RDF#A4": _a_kr_relay_zero,
    "RBH#A1": _a_pass_stop, "RBH#A2": _a_read_pass_evidence,
    "RBH#A3": _a_read_stop_blocker, "RBH#A4": _a_kr_relay_zero,
    "POR#A1": _a_pass_stop, "POR#A2": _a_patch_target, "POR#A3": _a_patch_keys,
    "POR#A4": _a_patch_pass_evidence, "POR#A5": _a_patch_no_py_modified, "POR#A6": _a_kr_relay_zero,
    "NA#A1": _a_nas_result, "NA#A2": _a_nas_pass, "NA#A3": _a_nas_fail_blocker,
    "NA#A4": _a_nas_stop_blocker, "NA#A5": _a_nas_no_overwrite, "NA#A6": _a_kr_relay_zero,
    "RC#A1": _a_reprocess_result, "RC#A2": _a_reprocess_source,
    "RC#A3": _a_reprocess_receipts, "RC#A4": _a_kr_relay_zero,
    "GW#A1": _a_gov_result, "GW#A2": _a_gov_pass, "GW#A3": _a_kr_relay_zero,
    "RAP#A1": _a_relay_pass, "RAP#A2": _a_relay_pass, "RAP#A3": _a_kr_relay_zero,
    "MJR#A1": _a_mozi_result, "MJR#A2": _a_mozi_pass, "MJR#A3": _a_mozi_no_action,
    "QKD#A1": _a_kr_relay_zero,  # 登记类占位，实际不参与执行基线
    "EXT#E1": _a_ext_probe,  # R2-② 仅 EXTRA_ASSERTIONS 可达的测试钩子
}


def evaluate_baseline(action, exec_result, contract, signed_command=None):
    """
    ③ 单一真源：读取 contract 中该 ACTION 的 baseline_assertions 并执行。
    任一合同断言无实现 -> UNSUPPORTED_ASSERTION（FAIL，不跳过、不默认PASS）。

    R2-②：EXTRA_ASSERTIONS 的唯一合法来源是 Signed Command（Intent -> Compiler -> Signed Command）。
    哪吒 / Executor / Result 无权提供、删除、修改验收标准；exec_result.EXTRA_ASSERTIONS 被完全忽略。
    """
    spec = contract.get("actions", {}).get(action, {})
    assertions = spec.get("baseline_assertions", [])
    for a in assertions:
        aid = a["id"] if isinstance(a, dict) else a
        fn = ASSERTION_IMPL.get(aid)
        if fn is None:
            return False, f"UNSUPPORTED_ASSERTION:{aid}"
        ok, why = fn(exec_result)
        if not ok:
            return False, why
    # R2-② EXTRA_ASSERTIONS 来自 Signed Command（加严，且必须已注册）
    extras = (signed_command or {}).get("extra_assertions") or []
    for eid in extras:
        fn = ASSERTION_IMPL.get(eid)
        if fn is None:
            return False, f"UNSUPPORTED_ASSERTION:{eid}"
        ok, why = fn(exec_result)
        if not ok:
            return False, why
    return True, "ok"


def _try_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def _independent_file_verify(order_id, signed_command, exec_result):
    """
    ④ 独立核验：对 READ_FILE / READBACK_HASH，独立读取真实目标并重算 SHA256，
    与 executor 自报的 AFTER_SHA256 比对。机器自报 PASS 不能成为 CLOSED 依据。
    证据记录的 ORDER/EVENT/ACTION/TARGET 绑定由 _evidence_record_binding 统一负责。
    """
    target = signed_command.get("target")
    if not target or not os.path.exists(str(target)):
        return False, ("TARGET_READ_FAIL", {"target": target})
    try:
        actual_sha = _sha256_file(target)
    except Exception as e:
        return False, ("TARGET_READ_FAIL", {"error": str(e)})
    # 核心：独立重算 sha 必须与 executor 自报 AFTER_SHA256 一致
    # 覆盖 假SHA / 旧Evidence复用 / Evidence属另一文件（sha 不一致）
    claimed = exec_result.get("AFTER_SHA256")
    if claimed != actual_sha:
        return False, ("EVIDENCE_SHA_MISMATCH",
                       {"recomputed": actual_sha[:16] + "...",
                        "claimed": str(claimed)[:16] + "..."})
    return True, ("ok", {})


def _evidence_record_binding(order_id, signed_command, exec_result):
    """
    R3-① 强制身份证（MANDATORY，非选填）：
    凡 Evidence 用于订单 CLOSED，其记录必须同时具备并严格匹配
    ORDER_ID / ACTION / TARGET 三项身份。
      - 任一字段缺失 -> 拒绝（EVIDENCE_ORDER_ID_MISSING / EVIDENCE_ACTION_MISSING / EVIDENCE_TARGET_MISSING）
      - 字段存在但与当前 Signed Command 不一致 -> 拒绝
        （EVIDENCE_NOT_FOR_THIS_ORDER / EVIDENCE_ACTION_MISMATCH / EVIDENCE_TARGET_MISMATCH）
    彻底废除「字段存在才检查、缺失则跳过」的旧逻辑。
    返回 None 表示身份绑定通过；否则返回 (REASON, DETAIL)。
    """
    ep = exec_result.get("EVIDENCE_PATH")
    if not ep or not os.path.exists(str(ep)):
        # 无证据记录（或路径不存在）：身份无法核验，
        # 交由 check_result 既有 step（EVIDENCE_INCOMPLETE / EVIDENCE_PATH_MISSING）拦截。
        return None
    rec = _try_json(ep)
    if not isinstance(rec, dict):
        # 记录不可解析 -> 无有效身份 -> 不得 CLOSED
        return ("EVIDENCE_ORDER_ID_MISSING", {"reason": "evidence record not parseable"})

    # ---- ORDER_ID 必填且必须一致 ----
    if "ORDER_ID" not in rec or rec.get("ORDER_ID") is None:
        return ("EVIDENCE_ORDER_ID_MISSING", {"missing": "ORDER_ID"})
    if str(rec.get("ORDER_ID")) != str(order_id):
        return ("EVIDENCE_NOT_FOR_THIS_ORDER",
                {"evidence_order": str(rec.get("ORDER_ID")), "current_order": str(order_id)})

    # ---- ACTION 必填且必须一致 ----
    if "ACTION" not in rec or rec.get("ACTION") is None:
        return ("EVIDENCE_ACTION_MISSING", {"missing": "ACTION"})
    if rec.get("ACTION") != signed_command.get("action"):
        return ("EVIDENCE_ACTION_MISMATCH",
                {"evidence_action": rec.get("ACTION"), "signed_action": signed_command.get("action")})

    # ---- TARGET 必填且必须一致 ----
    if "TARGET" not in rec or rec.get("TARGET") is None:
        return ("EVIDENCE_TARGET_MISSING", {"missing": "TARGET"})
    if rec.get("TARGET") != signed_command.get("target"):
        return ("EVIDENCE_TARGET_MISMATCH",
                {"evidence_target": rec.get("TARGET"), "signed_target": signed_command.get("target")})

    return None


def _evidence_content_binding(order_id, signed_command, exec_result):
    """
    R4-② Evidence 身份+内容强绑定（READ_FILE / READBACK_HASH）：
    除身份（ORDER_ID/ACTION/TARGET，由 _evidence_record_binding 负责）外，
    Evidence 记录必须与 exec_result 一致：RESULT / AFTER_SHA256 / SIZE / KR_RELAY。
      - 任一字段缺失 / 记录不可解析 -> OPEN（EVIDENCE_<FIELD>_MISSING）
      - 任一字段与 exec_result 不一致 -> OPEN（EVIDENCE_<FIELD>_MISMATCH）
    READ_FILE / READBACK_HASH：Evidence.AFTER_SHA256 必须等于 Result Gate 独立重算的目标 SHA256。
    返回 None 表示内容绑定通过；否则返回 (REASON, DETAIL)。
    """
    action = signed_command.get("action")
    ep = exec_result.get("EVIDENCE_PATH")
    if not ep or not os.path.exists(str(ep)):
        return None  # 无记录 -> 交由 EVIDENCE_INCOMPLETE / EVIDENCE_PATH_MISSING 拦截
    rec = _try_json(ep)
    if not isinstance(rec, dict):
        return ("EVIDENCE_RESULT_MISSING", {"reason": "evidence record not parseable"})

    # 内容四字段：rec 必须与 exec_result 一致（不可解析/缺失/不一致 -> OPEN）
    for f, (miss, mism) in (
        ("RESULT", ("EVIDENCE_RESULT_MISSING", "EVIDENCE_RESULT_MISMATCH")),
        ("AFTER_SHA256", ("EVIDENCE_SHA_MISSING", "EVIDENCE_SHA_MISMATCH")),
        ("SIZE", ("EVIDENCE_SIZE_MISSING", "EVIDENCE_SIZE_MISMATCH")),
        ("KR_RELAY", ("EVIDENCE_KR_RELAY_MISSING", "EVIDENCE_KR_RELAY_MISMATCH")),
    ):
        if f not in rec or rec.get(f) is None:
            return (miss, {"missing": f})
        if rec.get(f) != exec_result.get(f):
            return (mism, {"evidence": rec.get(f), "exec": exec_result.get(f)})

    # 独立重算（READ_FILE / READBACK_HASH）：Evidence.AFTER_SHA256 必须等于真实目标 SHA256
    target = signed_command.get("target")
    if target and os.path.exists(str(target)):
        try:
            actual_sha = _sha256_file(target)
        except Exception:
            actual_sha = None
        if actual_sha is not None and rec.get("AFTER_SHA256") != actual_sha:
            return ("EVIDENCE_SHA_MISMATCH",
                    {"recomputed": actual_sha[:16] + "...",
                     "evidence_sha": str(rec.get("AFTER_SHA256"))[:16] + "..."})
    return None


def _evidence_target_canonical(order_id, signed_command, exec_result):
    """
    R4.1-③ TARGET 审计双字段（READ_FILE / READBACK_HASH）：
      - 保留签令原始 TARGET（signed_command.target），Evidence.TARGET 必须与之严格一致；
      - Evidence 必须携带 TARGET_CANONICAL（规范化/实际解析路径），且等于 Result Gate
        独立重算的规范化实际读取对象路径（os.path.realpath）；
      - TARGET_CANONICAL 指向的文件必须真实存在。
    不得只靠人工事后解释（如 tests\\.. 字面量差异）——通道层已对规范化路径做硬核验。
    返回 None 表示通过；否则返回 (REASON, DETAIL)。
    """
    action = signed_command.get("action")
    if action not in ("READ_FILE", "READBACK_HASH"):
        return None
    ep = exec_result.get("EVIDENCE_PATH")
    if not ep or not os.path.exists(str(ep)):
        return None  # 无记录 -> 交由 EVIDENCE_INCOMPLETE / EVIDENCE_PATH_MISSING 拦截
    rec = _try_json(ep)
    if not isinstance(rec, dict):
        return ("EVIDENCE_TARGET_CANONICAL_MISSING", {"reason": "evidence record not parseable"})

    # 1) 原始 TARGET 必须与签令一致（再建一道硬闸，覆盖人工事后解释）
    if rec.get("TARGET") != signed_command.get("target"):
        return ("EVIDENCE_TARGET_MISMATCH",
                {"evidence_target": rec.get("TARGET"), "signed_target": signed_command.get("target")})

    # 2) TARGET_CANONICAL 必填
    canon = rec.get("TARGET_CANONICAL")
    if not canon:
        return ("EVIDENCE_TARGET_CANONICAL_MISSING", {"missing": "TARGET_CANONICAL"})

    # 3) TARGET_CANONICAL == Result Gate 独立重算的规范化实际读取对象路径
    expected = os.path.realpath(signed_command.get("target"))
    if os.path.normcase(os.path.abspath(canon)) != os.path.normcase(os.path.abspath(expected)):
        return ("EVIDENCE_TARGET_CANONICAL_MISMATCH",
                {"evidence_canonical": canon, "expected_canonical": expected})

    # 4) 实际读取对象必须真实存在（否则核验无意义）
    if not os.path.exists(canon):
        return ("EVIDENCE_TARGET_CANONICAL_READ_FAIL", {"path": canon})

    return None


def make_result_signature(order_id, exec_result):
    canon = f"{order_id}|{exec_result.get('ACTION')}|{exec_result.get('RESULT')}|{exec_result.get('AFTER_SHA256') or exec_result.get('RELAY_ACK_COMMENT_ID') or ''}"
    return hashlib.sha256(canon.encode("utf-8")).hexdigest()[:24]


def check_result(order_id, signed_command, exec_result, contract, ledger=None, timeout=None,
                 signing_key=None):
    """
    吃 signed_command + executor 返回的 exec_result，产出 verdict。
    返回 dict: {VERDICT, REASON, DETAIL}

    R2-A 独立强制验签：在任何 ORDER_ID/ACTION/TARGET/RESULT/EVIDENCE/ASSERTIONS 判断之前，
    必须先用与 Command Gate 一致的 canonicalization 重新验签。Executor 已验过 ≠ Result Gate
    此刻拿到的仍是原合法 Command；签后篡改必须在此被拦下。验签失败 → VERDICT=OPEN +
    SIGNATURE_INVALID，不降级 warning、不 CLOSED、保留原 ORDER 执行债。
    """
    # === R2-A 验签前置门（最高优先级，置于一切结果/证据/断言判断之前）===
    # 惰性 import 以避免与 compiler 的循环依赖（compiler 顶层 from result_gate import ASSERTION_IMPL）。
    from compiler import verify_command_signature
    _sig = verify_command_signature(signed_command, signing_key)
    if _sig != "VALID":
        return _open("SIGNATURE_INVALID", STATUS=_sig,
                     DETAIL="Result Gate 独立验签未通过，任何结果/证据/断言判断前即止步；原 ORDER 执行债保留。")
    action = signed_command.get("action")
    spec = contract.get("actions", {}).get(action, {})
    evidence_schema = spec.get("evidence_schema", [])

    # 1. ORDER_ID 对应
    if exec_result.get("ORDER_ID") and str(exec_result["ORDER_ID"]) != str(order_id):
        return _open("ORDER_ID_MISMATCH", got=exec_result.get("ORDER_ID"), expect=order_id)

    # 2. 实际 ACTION == 签发 ACTION（错动作即使机器返回 PASS 也 WRONG_ACTION）
    if exec_result.get("ACTION") and exec_result["ACTION"] != action:
        return _open("WRONG_ACTION", signed=action, actual=exec_result.get("ACTION"))

    # 3. TARGET 一致（signed_command 的 key 是小写 target；exec_result 沿用 bridge 大写 TARGET）
    if exec_result.get("TARGET") and exec_result.get("TARGET") != signed_command.get("target"):
        return _open("TARGET_MISMATCH", signed=signed_command.get("target"),
                     actual=exec_result.get("TARGET"))

    # 4. Evidence 必填字段非空
    missing = [e for e in evidence_schema if not exec_result.get(e)]
    if missing:
        return _open("EVIDENCE_INCOMPLETE", missing=missing)

    # 5. 独立核验 EVIDENCE_PATH 真实存在（不信任机器自报）
    ep = exec_result.get("EVIDENCE_PATH")
    if ep and not os.path.exists(str(ep)):
        return _open("EVIDENCE_PATH_MISSING", path=ep)

    # ③ R2-③ 证据强绑定当前 ORDER（全动作适用；旧/跨ORDER Evidence 复用 -> 拒绝）
    bind = _evidence_record_binding(order_id, signed_command, exec_result)
    if bind:
        return _open(bind[0], **bind[1])

    # ④ R4-② Evidence 身份+内容强绑定（READ_FILE/READBACK_HASH：rec 与 exec_result 一致；SHA 等于独立重算）
    if action in ("READ_FILE", "READBACK_HASH"):
        content = _evidence_content_binding(order_id, signed_command, exec_result)
        if content:
            return _open(content[0], **content[1])

    # ④ R4.1-③ TARGET 审计双字段（READ_FILE/READBACK_HASH：原始 TARGET 一致 + TARGET_CANONICAL 与实际读取对象一致）
    if action in ("READ_FILE", "READBACK_HASH"):
        tcanon = _evidence_target_canonical(order_id, signed_command, exec_result)
        if tcanon:
            return _open(tcanon[0], **tcanon[1])

    # ④ 独立重算 SHA256（READ_FILE / READBACK_HASH）
    if action in ("READ_FILE", "READBACK_HASH"):
        ok, why = _independent_file_verify(order_id, signed_command, exec_result)
        if not ok:
            return _open(why[0], **why[1])

    # 6. 重复 Result 检测
    if ledger is not None:
        sig = make_result_signature(order_id, exec_result)
        if ledger.is_duplicate_result(order_id, sig):
            return _open("DUPLICATE", signature=sig)
        ledger.mark_result(order_id, sig, "pending")

    # ③ 7. BASELINE ASSERTIONS（合同驱动的单一真源；R2-② Extra 来自 Signed Command）
    ok, why = evaluate_baseline(action, exec_result, contract, signed_command)
    if not ok:
        return _open("ASSERTION_FAILED", detail=why)

    # 8. 超时（executor 上报 took_sec）
    if timeout and isinstance(exec_result.get("took_sec"), (int, float)):
        if exec_result["took_sec"] > timeout:
            return _open("EXEC_TIMEOUT", took=exec_result["took_sec"], limit=timeout)

    return {"VERDICT": VERDICT_CLOSED, "REASON": "RESULT+EVIDENCE+ASSERTION PASS"}


def result_signature_of(order_id, exec_result):
    return make_result_signature(order_id, exec_result)
