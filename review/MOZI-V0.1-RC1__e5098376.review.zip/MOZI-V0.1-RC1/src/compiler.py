#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨子 V0.1 · Compiler + Command Gate (R1)
=========================================
Compiler: Intent -> Command（确定性，禁止调用 LLM 决定是否合法）。
Command Gate: 签令前最后确定性审核 + HMAC 签名（密钥不硬编码进仓库）。

R1 新增纪律（对应嗨姐审核 R1-①/②/⑤）：
① ACTION params 严格白名单：REQUIRED/OPTIONAL 以 contract_v0.1.json 为唯一合法来源；
   缺 REQUIRED -> REJECT；未知 param -> UNKNOWN_PARAM REJECT；禁静默删字段；禁嵌套夹带第二 ACTION。
② risk 不得由 Intent 降级：Contract 定义最低风险等级；Intent 只能提高，不得降低。
⑤ 签名成为真实执行边界：提供 verify_command_signature，供 Executor 入口与审计复用。

R2 新增纪律（对应嗨姐审核 R2-①/②/③）：
① 统一参数模型：Contract 与 Compiler 同源，所有 ACTION 输入位于 intent.params（单一位置），
   TARGET 用顶层 intent.target（合同 "TARGET" 哨兵）；required_params/optional_params 用裸参数名。
② Extra Assertions 必须来自 Signed Command：编译期校验只引用已注册 id（未知 -> UNSUPPORTED_ASSERTION REJECT），
   且经 Intent -> Compiler -> Signed Command 流动；Result Gate 仅从 Signed Command 读取，忽略 exec_result.EXTRA_ASSERTIONS。
③ Evidence 绑定（见 result_gate）；Compiler 携带 event_id（若 Intent 提供）供绑定。
"""
import hmac
import hashlib
import datetime
import json
import re

from result_gate import ASSERTION_IMPL  # R2-②：编译期校验 extra_assertions 只引用已注册 id

# Intent 顶层允许的键（白名单）。任何合同未定义的额外键 -> ILLEGAL_EXTRA_PARAM。
ALLOWED_INTENT_KEYS = {
    "order_id", "envelope", "subtype", "action", "target", "params",
    "assertion_profile", "extra_assertions", "risk_class", "timeout",
    "idempotency_key", "contract_version", "event_id",
}


def _now_iso():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _canonical(obj):
    """确定性序列化（排序键），用于签名与比对。"""
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


# ---- ② risk 等级 ----
def _risk_level(r):
    if not r:
        return 0
    m = re.match(r"L(\d)", str(r))
    return int(m.group(1)) if m else 0


def _max_risk(a, b):
    """取两者中较高风险等级（Contract 最低等级不可被 Intent 更低值覆盖）。"""
    la, lb = _risk_level(a), _risk_level(b)
    if la >= lb:
        return a if a else b
    return b


# ---- ① 统一参数模型（R2-①，Contract 与 Compiler 同源）----
def _param_spec(spec):
    """
    R2-①：contract 的 required_params / optional_params 使用「裸参数名」（不含 params. 前缀）。
    约定：
      - TARGET 是动作主体，使用顶层 intent.target；合同以 "TARGET" 哨兵声明「必填顶层 target」。
      - 其余所有动作输入位于 intent.params（单一位置）。
    返回 (required_non_target, allowed_params_set)。
    """
    req = spec.get("required_params", []) or []
    opt = spec.get("optional_params", []) or []
    required_non_target = [p for p in req if p != "TARGET"]
    allowed = set(required_non_target) | set(opt)
    return required_non_target, allowed


def compile_intent(intent, contract):
    """
    Intent -> Command。返回 dict：
      COMMAND_REJECTED=True 时含 REASON / FIELD
      COMMAND_REJECTED=False 时含 command
    """
    if not isinstance(intent, dict):
        return {"COMMAND_REJECTED": True, "REASON": "INTENT_NOT_OBJECT"}

    # ---- 顶层未定义字段 -> 整令 REJECT（禁止静默删除）----
    extra = [k for k in intent if k not in ALLOWED_INTENT_KEYS]
    if extra:
        return {"COMMAND_REJECTED": True, "REASON": "ILLEGAL_EXTRA_PARAM",
                "FIELD": ",".join(sorted(extra))}

    action = intent.get("action")
    if not action:
        return {"COMMAND_REJECTED": True, "REASON": "NO_ACTION"}

    # ---- 未知 ACTION -> REJECT ----
    if action not in contract.get("actions", {}):
        return {"COMMAND_REJECTED": True, "REASON": "UNKNOWN_ACTION", "FIELD": str(action)}

    spec = contract["actions"][action]

    params = intent.get("params") or {}
    if not isinstance(params, dict):
        return {"COMMAND_REJECTED": True, "REASON": "PARAMS_NOT_OBJECT"}

    # ---- ⑥ 禁嵌套夹带第二 ACTION ----
    if "action" in params and params["action"] != action:
        return {"COMMAND_REJECTED": True, "REASON": "MULTI_ACTION_IN_ONE_COMMAND",
                "FIELD": "params.action"}

    # ---- ① 统一参数白名单（Contract 为唯一来源，裸参数名）----
    required_non_target, allowed_params = _param_spec(spec)
    # 未知 param -> 整令 REJECT（禁静默忽略）
    for k in params:
        if k not in allowed_params:
            return {"COMMAND_REJECTED": True, "REASON": "UNKNOWN_PARAM",
                    "FIELD": f"params.{k}"}
    # 缺 REQUIRED 参数（位于 params 内）-> REJECT
    for nr in required_non_target:
        if not params.get(nr):
            return {"COMMAND_REJECTED": True, "REASON": "MISSING_REQUIRED_PARAM",
                    "FIELD": f"params.{nr}"}
    # TARGET 哨兵 -> 顶层 target 必填
    if "TARGET" in (spec.get("required_params") or []) and not intent.get("target"):
        return {"COMMAND_REJECTED": True, "REASON": "MISSING_REQUIRED_PARAM",
                "FIELD": "target"}

    # ---- contract_version 校验 ----
    cv = intent.get("contract_version")
    if cv and cv != contract.get("contract_version"):
        return {"COMMAND_REJECTED": True, "REASON": "CONTRACT_VERSION_MISMATCH",
                "EXPECTED": contract.get("contract_version"), "GOT": cv}

    # ---- ② risk 不得降级：取 Contract 最低等级与 Intent 的较高者 ----
    intent_risk = intent.get("risk_class")
    contract_risk = spec.get("risk_class")
    eff_risk = _max_risk(intent_risk, contract_risk)

    # ---- ② Extra Assertions 编译期校验：只引用已注册 id（加严），未知 -> REJECT ----
    # 唯一合法数据流：Intent.extra_assertions -> Compiler -> Signed Command -> Result Gate。
    # 哪吒 / Executor / Result 无权提供、删除、修改验收标准。
    extras = intent.get("extra_assertions") or []
    if not isinstance(extras, list):
        return {"COMMAND_REJECTED": True, "REASON": "BAD_EXTRA_ASSERTIONS"}
    for eid in extras:
        if eid not in ASSERTION_IMPL:
            return {"COMMAND_REJECTED": True, "REASON": "UNSUPPORTED_ASSERTION",
                    "FIELD": str(eid)}

    # 构造 Command（不丢任何原始合法字段）
    cmd = {
        "order_id": intent.get("order_id"),
        "contract_version": contract.get("contract_version"),
        "envelope": intent.get("envelope"),
        "subtype": intent.get("subtype"),
        "action": action,
        "target": intent.get("target"),
        "params": params,
        "assertion_profile": intent.get("assertion_profile", "BASELINE"),
        "extra_assertions": extras,  # 已校验，来自 Intent，流向 Signed Command
        "risk_class": eff_risk,
        "timeout": intent.get("timeout"),
        "idempotency_key": intent.get("idempotency_key", intent.get("order_id")),
        "event_id": intent.get("event_id"),  # R2-③：供 Evidence 绑定
    }
    return {"COMMAND_REJECTED": False, "command": cmd}


def command_gate(command, contract, signing_key=None):
    """
    签令前最后确定性审核 + HMAC 签名。
    L3 / kr_gate=PENDING_KR_GATE -> 不签，转 KR_GATE。
    签名只证明「这条 Command 经过墨子」，不证明业务正确。
    """
    c = command.get("command") if isinstance(command, dict) and "command" in command else command
    if not isinstance(c, dict):
        return {"SIGNED": False, "REASON": "EMPTY_COMMAND"}

    # 必填字段审核
    for f in ("order_id", "target", "action", "params", "idempotency_key",
              "risk_class", "assertion_profile"):
        if c.get(f) is None:
            return {"SIGNED": False, "REASON": "GATE_FIELD_MISSING", "FIELD": f}

    # 风险裁决（需求书第九节 + R1-②）
    risk = c.get("risk_class")
    spec = contract["actions"].get(c["action"], {})
    kg = spec.get("kr_gate")
    if risk == "L3" or kg in ("PENDING_KR_GATE", "true") or kg is True:
        return {"SIGNED": False, "REASON": "KR_GATE_REQUIRED", "ACTION": c["action"],
                "NOTE": "L3 / 待裁定风险必须 KR 手动越过；墨子不自行签发"}

    # 超时合法性
    to = c.get("timeout")
    if to is not None and (not isinstance(to, (int, float)) or to <= 0):
        return {"SIGNED": False, "REASON": "INVALID_TIMEOUT"}

    # HMAC 签名
    canon = _canonical({k: c[k] for k in sorted(c)})
    if signing_key:
        sig = hmac.new(signing_key.encode("utf-8"), canon.encode("utf-8"),
                        hashlib.sha256).hexdigest()
    else:
        sig = "UNSIGNED_DRY"  # dry 模式：明确标注未签名，绝不冒充已签
    c["signature"] = sig
    c["signed_at"] = _now_iso()
    return {"SIGNED": True, "signed_command": c, "signature": sig}


def verify_command_signature(signed_command, signing_key):
    """
    R1-⑤：签名执行边界验证。供 Executor 入口与 Result Gate 复用。
    返回：VALID / NO_COMMAND / NO_SIGNATURE / UNSIGNED_DRY / NO_KEY / SIGNATURE_INVALID
    """
    if not isinstance(signed_command, dict):
        return "NO_COMMAND"
    sig = signed_command.get("signature")
    if not sig:
        return "NO_SIGNATURE"
    if sig == "UNSIGNED_DRY":
        return "UNSIGNED_DRY"
    if not signing_key:
        return "NO_KEY"
    # 排除签名元数据（signature / signed_at），重建签名时的 canonical 负载
    c = {k: signed_command[k] for k in signed_command if k not in ("signature", "signed_at")}
    canon = _canonical({k: c[k] for k in sorted(c)})
    expect = hmac.new(signing_key.encode("utf-8"), canon.encode("utf-8"),
                      hashlib.sha256).hexdigest()
    return "VALID" if hmac.compare_digest(expect, sig) else "SIGNATURE_INVALID"
