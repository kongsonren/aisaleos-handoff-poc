#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨子 V0.1 · 主链路整合（思→意→编→令→干→验→果）
================================================
CLI: python mozi.py --intent <intent.json> [--signing-key <key>]
确定性，禁调 LLM。把 Intent 跑完整链：
  INTENT_RECEIVED -> COMPILED -> SIGNED_ISSUED -> RECEIVED -> RUNNING
  -> RESULT_RECEIVED -> (VERIFIED -> CLOSED) | (OPEN + 异常态)

process() 接受 executor 注入，便于测试用 fake executor 做红队。
"""
import sys
import os
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from contract import load_contract
from compiler import compile_intent, command_gate
from result_gate import check_result
from ledger import Ledger
from executor import execute

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LEDGER_PATH = os.path.join(ROOT, "mozi_ledger.json")


def process(intent, contract=None, ledger=None, executor=execute,
            signing_key=None, ledger_path=LEDGER_PATH):
    contract = contract or load_contract()
    ledger = ledger or Ledger(ledger_path)
    order_id = intent.get("order_id")
    if not order_id:
        return {"ERROR": "NO_ORDER_ID"}

    # R4-① 订单唯一性：同一 ORDER_ID 已存在，立即拒绝。
    # 不得编令、不得签令、不得调用 executor、不得改写旧订单。
    if ledger.get(order_id) is not None:
        return {"order_id": order_id, "REJECTED": {"REASON": "DUPLICATE_ORDER_REJECTED"},
                "state": ledger.get(order_id)["state"]}

    ledger.create(order_id, intent)
    ledger.transition(order_id, "COMPILED")

    # 编
    comp = compile_intent(intent, contract)
    if comp.get("COMMAND_REJECTED"):
        ledger.transition(order_id, "COMMAND_REJECTED", comp.get("REASON"))
        return {"order_id": order_id, "stage": "COMPILE", "REJECTED": comp,
                "state": ledger.get(order_id)["state"]}

    # 审令 / 签令
    gate = command_gate(comp, contract, signing_key)
    if not gate.get("SIGNED"):
        ledger.transition(order_id, "COMMAND_REJECTED", gate.get("REASON"))
        return {"order_id": order_id, "stage": "GATE", "REJECTED": gate,
                "state": ledger.get(order_id)["state"]}
    sc = gate["signed_command"]

    # ⑤ UNSIGNED_DRY 不得进入真实执行路径：Dry Run 标记在正式 process 中必须止步。
    if sc.get("signature") == "UNSIGNED_DRY":
        ledger.transition(order_id, "COMMAND_REJECTED", "UNSIGNED_DRY_NOT_FOR_REAL_EXEC")
        return {"order_id": order_id, "stage": "GATE", "REJECTED": {"REASON": "UNSIGNED_DRY_NOT_FOR_REAL_EXEC"},
                "state": ledger.get(order_id)["state"]}

    # 干
    ledger.transition(order_id, "SIGNED_ISSUED")
    ledger.transition(order_id, "RECEIVED")
    ledger.transition(order_id, "RUNNING")
    exec_result = executor(sc)
    ledger.transition(order_id, "RESULT_RECEIVED")

    # 验 + 果（R2-A：透传 signing_key，使 Result Gate 能独立强制验签）
    verdict = check_result(order_id, sc, exec_result, contract, ledger, signing_key=signing_key)
    if verdict["VERDICT"] == "CLOSED":
        ledger.transition(order_id, "VERIFIED")
        ledger.transition(order_id, "CLOSED")
        # R4.1-② 修账本终态：CLOSED 必须同步写 last_verdict=CLOSED
        ledger.set_last_verdict(order_id, "CLOSED")
    else:
        detail = json.dumps(verdict.get("DETAIL", {}), ensure_ascii=False)[:200]
        ledger.transition(order_id, verdict["REASON"], detail)
        # R4.1-② 拒绝/OPEN 不得伪写 CLOSED：写诚实的 OPEN:<REASON>
        ledger.set_last_verdict(order_id, "OPEN:" + verdict["REASON"])

    return {"order_id": order_id, "signed_command": sc,
            "exec_result": exec_result, "verdict": verdict,
            "state": ledger.get(order_id)["state"]}


def main():
    ap = argparse.ArgumentParser(description="墨子 V0.1 控制面 CLI")
    ap.add_argument("--intent", required=True, help="Intent JSON 路径")
    ap.add_argument("--signing-key", default=os.environ.get("MOZI_SIGNING_KEY"),
                    help="HMAC 签名密钥（默认读 MOZI_SIGNING_KEY 环境变量）")
    args = ap.parse_args()
    intent = json.load(open(args.intent, encoding="utf-8"))
    out = process(intent, executor=execute, signing_key=args.signing_key)
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
