#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨子 V0.1 · State / Ledger 最小状态机（果）
===========================================
每令唯一 ORDER_ID。原则（需求书第七节）：
  无果之令皆为债。无证之果不算果。无断言通过之证，不得销账。

正常态：INTENT_RECEIVED -> COMPILED -> SIGNED_ISSUED -> RECEIVED -> RUNNING
       -> RESULT_RECEIVED -> VERIFIED -> CLOSED
异常态：COMMAND_REJECTED / RECEIVE_TIMEOUT / EXEC_TIMEOUT / WRONG_ACTION
       / EVIDENCE_INCOMPLETE / ASSERTION_FAILED / DUPLICATE / UNKNOWN
"""
import os
import json
import datetime

STATES_NORMAL = [
    "INTENT_RECEIVED", "COMPILED", "SIGNED_ISSUED", "RECEIVED", "RUNNING",
    "RESULT_RECEIVED", "VERIFIED", "CLOSED",
]
STATES_ABNORMAL = [
    "COMMAND_REJECTED", "RECEIVE_TIMEOUT", "EXEC_TIMEOUT", "WRONG_ACTION",
    "EVIDENCE_INCOMPLETE", "ASSERTION_FAILED", "DUPLICATE", "UNKNOWN",
]


def _now():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class Ledger:
    def __init__(self, path):
        self.path = path
        self.data = {"orders": {}}
        if os.path.exists(path):
            try:
                self.data = json.load(open(path, encoding="utf-8"))
            except Exception:
                pass
        self.data.setdefault("orders", {})

    def _flush(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.path)
        # 回读核验
        rb = json.load(open(self.path, encoding="utf-8"))
        assert rb.get("orders") is not None

    def _append_event(self, order_id, state, note=None):
        o = self.data["orders"][order_id]
        o["events"].append({"ts": _now(), "state": state, "note": note})

    def create(self, order_id, meta=None):
        if order_id in self.data["orders"]:
            return False
        self.data["orders"][order_id] = {
            "order_id": order_id, "state": "INTENT_RECEIVED",
            "events": [], "meta": meta or {},
        }
        self._append_event(order_id, "INTENT_RECEIVED")
        self._flush()
        return True

    def transition(self, order_id, to_state, note=None):
        if order_id not in self.data["orders"]:
            return False
        self.data["orders"][order_id]["state"] = to_state
        self._append_event(order_id, to_state, note)
        self._flush()
        return True

    def get(self, order_id):
        return self.data["orders"].get(order_id)

    def is_duplicate_result(self, order_id, result_signature):
        o = self.data["orders"].get(order_id, {})
        return result_signature in o.get("result_signatures", [])

    def mark_result(self, order_id, result_signature, verdict):
        o = self.data["orders"].get(order_id)
        if not o:
            return
        o.setdefault("result_signatures", [])
        if result_signature not in o["result_signatures"]:
            o["result_signatures"].append(result_signature)
        o["last_verdict"] = verdict
        o["last_result_signature"] = result_signature
        self._flush()

    def set_last_verdict(self, order_id, verdict):
        """R4.1-② 修账本终态：订单最终 CLOSED 时同步写 last_verdict=CLOSED；
        OPEN/拒绝时写诚实的 OPEN:<REASON>（不得伪写 CLOSED）。"""
        o = self.data["orders"].get(order_id)
        if not o:
            return
        o["last_verdict"] = verdict
        self._flush()

    def summary(self):
        out = {}
        for oid, o in self.data["orders"].items():
            out[oid] = {"state": o["state"], "events": len(o["events"]),
                        "last_verdict": o.get("last_verdict")}
        return out
