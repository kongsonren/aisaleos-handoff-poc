#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨子 V0.1 · Executor（干）— R1
=======================
哪吒执行层：把已签发 Command 派发到真实 1WB 执行代码（wb1_local_exec_bridge 白名单动作）。
仅承接 Compiler/Gate 已签发的 Command；不自行决定合法性（合法性在墨子上游）。

R1-⑤：Executor 入口必须验签——没有合法签名的 Command 不能进入真实执行路径。
  - 无签名 / 签名错 / canonical 被篡改 -> SIGNATURE_REJECTED，拒绝执行。
  - UNSIGNED_DRY（Dry Run 标记）不得进入真实 1WB 执行路径。
签名密钥只从运行时环境变量 MOZI_SIGNING_KEY 读取，绝不写死源码、不落盘、不进报告/Comment/Ledger。
"""
import sys
import os
import time

WB1 = os.path.expanduser("~/.wb1")
if WB1 not in sys.path:
    sys.path.insert(0, WB1)


def _ctx(order_id):
    # R3-②：把 order_id 一并交给 bridge，使其生成的 Evidence 携带身份 ORDER_ID。
    return {"event_id": order_id, "order_id": order_id, "trigger_body": None}


def execute(signed_command):
    from compiler import verify_command_signature

    # ⑤ 签名执行边界：先验签，再执行。
    key = os.environ.get("MOZI_SIGNING_KEY")
    status = verify_command_signature(signed_command, key)
    if status != "VALID":
        return {"RESULT": "STOP", "BLOCKER": "SIGNATURE_REJECTED", "DETAIL": status,
                "ACTION": signed_command.get("action"),
                "TARGET": signed_command.get("target"),
                "ORDER_ID": signed_command.get("order_id")}

    import wb1_local_exec_bridge as bridge  # 真实 1WB 执行代码（已 VERIFIED）
    action = signed_command["action"]
    target = signed_command["target"]
    params = signed_command.get("params", {}) or {}
    ctx = _ctx(signed_command["order_id"])
    t0 = time.time()
    try:
        if action == "READ_FILE":
            res = bridge.act_read_file(target, params, ctx)
        elif action == "READBACK_HASH":
            res = bridge.act_readback_hash(target, params, ctx)
        elif action == "NAS_ARCHIVE":
            res = bridge.act_nas_archive(target, params, ctx)
        elif action == "PATCH_OWN_ROUTER":
            res = bridge.act_patch_own_router(target, params, ctx)
        elif action == "REPROCESS_COMMENT":
            res = bridge.act_reprocess_comment(target, params, ctx)
        else:
            return {"RESULT": "STOP", "BLOCKER": "EXECUTOR_NO_HANDLER",
                    "ACTION": action, "TARGET": target,
                    "ORDER_ID": signed_command["order_id"]}
    except Exception as e:
        return {"RESULT": "FAIL", "BLOCKER": "EXECUTOR_EXCEPTION",
                "NOTE": str(e), "ACTION": action, "TARGET": target,
                "ORDER_ID": signed_command["order_id"]}
    # 统一回填 ORDER_ID / ACTION / TARGET，供 Result Gate 比对
    res["ORDER_ID"] = signed_command["order_id"]
    res["ACTION"] = action
    res["TARGET"] = target
    res["took_sec"] = round(time.time() - t0, 3)
    return res
