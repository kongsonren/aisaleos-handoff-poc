#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨子 V0.1 · Contract Registry 加载器
唯一事实来源：contract_v0.1.json（由 CONTRACT_DISCOVERY_V0.1 提炼，VERIFIED 子集）。
Compiler / Command Gate / Result Gate 只允许引用本 Registry 中 STATUS=VERIFIED 的 ACTION。
"""
import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_REG_PATH = os.path.join(os.path.dirname(_HERE), "contract_v0.1.json")


def load_contract(path=None):
    p = path or _REG_PATH
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def verified_actions(contract):
    """返回可执行（有 side effect）的 VERIFIED ACTION 名集合。"""
    return [k for k, v in contract.get("actions", {}).items()
            if v.get("status", "").startswith("VERIFIED")]


def get_action_spec(contract, action):
    return contract.get("actions", {}).get(action)


def is_executable(contract, action):
    """是否允许形成 COMMAND（排除 EXECUTION=NONE 的登记类）。"""
    spec = get_action_spec(contract, action)
    if not spec:
        return False
    if spec.get("execution") == "NONE":
        return False
    return spec.get("status", "").startswith("VERIFIED")
