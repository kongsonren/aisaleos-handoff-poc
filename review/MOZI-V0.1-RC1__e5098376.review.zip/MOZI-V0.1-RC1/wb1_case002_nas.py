"""Fail-closed UNC validation; no credentials and no local fallback."""
import ctypes
from ctypes import wintypes
import hashlib
import ntpath
import os
import uuid
from wb1_case002_trace import event, traced

NAS_ROOT = r"\\192.168.2.107\AI-SalesOS 仓库\AISALEOS_SHARED"
DEST = NAS_ROOT + r"\KR原著库\中秋思想母包\2026-09-27"


def canonical(path):
    p = os.fspath(path)
    if p.startswith('\\\\?\\UNC\\'):
        p = '\\\\' + p[8:]
    if not p.startswith('\\\\') or p.startswith(('\\\\?\\', '\\\\.\\')):
        raise ValueError('UNC_REQUIRED')
    if any(s in ('.', '..') for s in p.replace('/', '\\').split('\\')):
        raise ValueError('TRAVERSAL')
    if ':' in p or '\x00' in p:
        raise ValueError('INVALID_UNC')
    return ntpath.normcase(ntpath.normpath(p))


def require_scope(path):
    p, root = canonical(path), canonical(NAS_ROOT)
    if p != root and not p.startswith(root + '\\'):
        raise ValueError('OUTSIDE_REAL_NAS_ROOT')
    return p


@traced('nas.verify_remote')
def verify_remote(path):
    """Inspect an existing object by Windows handle, not its display label."""
    expected = require_scope(path)
    event('REMOTE_PATH_CHECK', path=os.fspath(path), expected=expected)
    if os.name != 'nt':
        raise OSError('WINDOWS_REMOTE_HANDLE_REQUIRED')
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.GetDriveTypeW.argtypes = [wintypes.LPCWSTR]
    k.GetDriveTypeW.restype = wintypes.UINT
    share = ntpath.splitdrive(NAS_ROOT)[0] + '\\'
    drive_type = k.GetDriveTypeW(share)
    drive_error = ctypes.get_last_error()
    event('GET_DRIVE_TYPE', share=share, result=drive_type, last_error=drive_error)
    if drive_type != 4:
        raise OSError('DRIVE_REMOTE_REQUIRED')
    k.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                             wintypes.LPVOID, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    k.CreateFileW.restype = wintypes.HANDLE
    k.GetFinalPathNameByHandleW.argtypes = [wintypes.HANDLE, wintypes.LPWSTR,
                                         wintypes.DWORD, wintypes.DWORD]
    k.GetFinalPathNameByHandleW.restype = wintypes.DWORD
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    k.CloseHandle.restype = wintypes.BOOL
    h = k.CreateFileW(os.fspath(path), 0, 7, None, 3, 0x02000000, None)
    open_error = ctypes.get_last_error()
    event('CREATE_FILE_HANDLE', path=os.fspath(path), success=h != wintypes.HANDLE(-1).value,
          last_error=open_error, error_text=ctypes.FormatError(open_error) if h == wintypes.HANDLE(-1).value else None)
    if h == wintypes.HANDLE(-1).value:
        raise OSError('REMOTE_HANDLE_OPEN_FAILED')
    try:
        buf = ctypes.create_unicode_buffer(32768)
        n = k.GetFinalPathNameByHandleW(h, buf, len(buf), 0)
        final_error = ctypes.get_last_error()
        event('FINAL_HANDLE_PATH', path=os.fspath(path), length=n,
              final_path=buf.value if n and n < len(buf) else None,
              last_error=final_error, error_text=ctypes.FormatError(final_error) if not n else None)
        if not n or n >= len(buf) or canonical(buf.value) != expected:
            raise OSError('REMOTE_FINAL_PATH_MISMATCH')
        return buf.value
    finally:
        k.CloseHandle(h)


@traced('nas.guard_archive_root')
def guard_archive_root(root):
    if canonical(root) != canonical(NAS_ROOT):
        raise ValueError('ARCHIVE_ROOT_MISMATCH')
    return verify_remote(root)


@traced('nas.readback')
def readback(path, payload):
    event('READBACK_START', path=path, expected_bytes=len(payload), expected_sha256=hashlib.sha256(payload).hexdigest())
    verify_remote(path)
    with open(path, 'rb') as f:
        data = f.read(len(payload) + 1)
    final = verify_remote(path)
    if data != payload:
        raise ValueError('EXISTING_FILE_OR_READBACK_CONFLICT')
    event('READBACK_PASS', path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), final_path=final)
    return {'PATH': path, 'BYTES': len(data), 'SHA256': hashlib.sha256(data).hexdigest(),
            'READBACK': 'PASS', 'STORAGE_ROOT': NAS_ROOT,
            'FINAL_HANDLE_PATH': final, 'STORAGE_ROOT_VERIFIED': True}


@traced('nas.write_prepared_impl')
def write_prepared(documents):
    """Exact prepared bytes only. Parent must already exist; never overwrite."""
    guard_archive_root(NAS_ROOT)
    ensure_authorized_destination()
    verify_remote(DEST)
    event('DESTINATION_VERIFIED', path=DEST)
    targets = []
    for name, payload in documents:
        if ntpath.basename(name) != name or not name.endswith('.md'):
            raise ValueError('INVALID_FILENAME')
        path = ntpath.join(DEST, name)
        require_scope(path)
        if os.path.lexists(path):
            readback(path, payload)  # preflight all conflicts before any write
        targets.append((path, payload))
    rows = []
    for path, payload in targets:
        if not os.path.lexists(path):
            verify_remote(DEST)
            tmp = path + '.case002-' + uuid.uuid4().hex + '.partial'
            event('FILE_WRITE_START', path=path, temporary_path=tmp, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())
            # Keep a partial file on failure for evidence; no destructive cleanup.
            with open(tmp, 'xb') as f:
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
            readback(tmp, payload)
            event('FILE_RENAME_START', source=tmp, destination=path)
            try:
                os.rename(tmp, path)  # Windows rename does NOT replace an existing target
            except FileExistsError:
                event('FILE_RENAME_CONCURRENT_TARGET', path=path, temporary_path=tmp)
                pass  # concurrent winner must still pass byte-exact readback
        rows.append(readback(path, payload))
    return rows


@traced('nas.ensure_authorized_destination')
def ensure_authorized_destination():
    """KR authorized only these two fixed children under the existing library."""
    parent = NAS_ROOT + r'\KR原著库'
    verify_remote(parent)
    for name in ('中秋思想母包', '2026-09-27'):
        child = ntpath.join(parent, name)
        require_scope(child)
        verify_remote(parent)
        event('AUTHORIZED_DIRECTORY_CREATE_START', path=child)
        try:
            os.mkdir(child)
        except FileExistsError:
            if not os.path.isdir(child):
                raise
        verify_remote(child)
        event('AUTHORIZED_DIRECTORY_VERIFIED', path=child)
        parent = child
