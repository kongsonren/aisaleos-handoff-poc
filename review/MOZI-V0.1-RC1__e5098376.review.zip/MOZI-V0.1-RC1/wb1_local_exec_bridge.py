#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
1WB 受控本地执行桥 (local_exec_bridge) V0.1
================================================
依据 [HAI→1WB][PROPOSAL][LOCAL-EXEC-BRIDGE-V0.1] (Issue #6 comment 5758562033) 实现。

设计原则（不可协商）：
- #6 只做运输/审计；本桥是 1WB 本机唯一受控执行入口。
- 白名单仅 5 个动作，无任意 shell、无任意代码执行、无 eval/exec、无 subprocess。
  READ_FILE / PATCH_OWN_ROUTER / REPROCESS_COMMENT / NAS_ARCHIVE / READBACK_HASH
- 路径白名单 + 目录穿越拦截 + 凭证文件硬拒（secrets 永不读、永不打印、永不外传）。
- 写白名单仅：NAS KR原著库 / ~/.wb1/exec_results / ~/.wb1/router_rules.json。
- 凭证：本桥自身不读任何 PAT/Token；需要 GitHub 时复用调用方 (heartbeat) 的运行期凭据。
- 不碰 2WB / 不动 NAS Egress Publisher / 不做外宣。
- 每次执行返回：EVENT_ID/ACTION/TARGET/BEFORE_SHA256/AFTER_SHA256/RESULT/EVIDENCE_PATH/KR_RELAY=0。
- 高风险/不可逆 -> 由 heartbeat 在派发前拦到 KR_GATE，本桥不接该类 SUBTYPE。
"""
import os, json, re, hashlib, datetime, difflib

WB1 = os.path.expanduser("~/.wb1")
NAS_ROOT = r"\\192.168.2.107\AI-SalesOS 仓库\AISALEOS_SHARED"
KR_VAULT = os.path.join(NAS_ROOT, "KR原著库")
PROJECT_DIR = r"C:\Users\59605\.workbuddy\projects\c-Users-59605-WorkBuddy-2026-07-07-01-11-02"
XIMAO_DIR = r"C:\Users\59605\希懋-SM1191-产品资产"
ROUTER_RULES = os.path.join(WB1, "router_rules.json")
EVID_DIR = os.path.join(WB1, "exec_results")
BRIDGE_LEDGER = os.path.join(WB1, "exec_bridge_ledger.json")
REPO = "kongsonren/aisaleos-handoff-poc"
ISSUE = 6

# ---- 白名单动作（唯一可执行集合）----
BRIDGE_ACTIONS = ["READ_FILE", "PATCH_OWN_ROUTER", "REPROCESS_COMMENT", "NAS_ARCHIVE", "READBACK_HASH"]

# ---- 路径安全 ----
ALLOWED_READ_ROOTS = [NAS_ROOT, PROJECT_DIR, WB1, XIMAO_DIR]
ALLOWED_WRITE_ROOTS = [KR_VAULT, EVID_DIR]
ALLOWED_WRITE_FILES = [ROUTER_RULES]
DENY_SUBSTR = ("github_pat", ".lark-cli", "id_rsa", ".ssh", "token", "secret",
               "credential", "password", ".pem", ".key", "device_code", "verify_url")


def now_iso():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def _norm(p):
    return os.path.normcase(os.path.normpath(os.path.abspath(p)))


def _under(path, roots):
    p = _norm(path)
    for r in roots:
        rn = _norm(r)
        if p == rn or p.startswith(rn + os.sep):
            return True
    return False


def _denied(path):
    low = path.replace(chr(92), "/").lower()
    return any(d in low for d in DENY_SUBSTR)


def check_read_path(path):
    if _denied(path):
        raise PermissionError(f"DENY_PATH(secret-pattern): {path}")
    if not _under(path, ALLOWED_READ_ROOTS):
        raise PermissionError(f"DENY_PATH(outside read roots): {path}")


def check_write_path(path):
    if _denied(path):
        raise PermissionError(f"DENY_PATH(secret-pattern): {path}")
    if path and _norm(path) in [_norm(x) for x in ALLOWED_WRITE_FILES]:
        return
    if not _under(path, ALLOWED_WRITE_ROOTS):
        raise PermissionError(f"DENY_PATH(outside write roots): {path}")


def write_evidence(event_id, action, target, payload):
    os.makedirs(EVID_DIR, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", f"{event_id}__{action}")[:120]
    fp = os.path.join(EVID_DIR, safe + ".json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return fp


def ledger_append(rec):
    L = {"entries": []}
    if os.path.exists(BRIDGE_LEDGER):
        try:
            L = json.load(open(BRIDGE_LEDGER, encoding="utf-8"))
        except Exception:
            pass
    L.setdefault("entries", []).append(rec)
    tmp = BRIDGE_LEDGER + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(L, f, ensure_ascii=False, indent=2)
    os.replace(tmp, BRIDGE_LEDGER)


def _result(ctx, action, target, before, after, result, note="", **extra):
    event_id = ctx.get("event_id")
    order_id = ctx.get("order_id") or event_id
    payload = {
        "EVENT_ID": event_id, "ORDER_ID": order_id, "ACTION": action, "TARGET": target,
        "BEFORE_SHA256": before or "", "AFTER_SHA256": after or "",
        "RESULT": result, "NOTE": note, "KR_RELAY": 0, "AT": now_iso(),
    }
    payload.update(extra)
    ev = write_evidence(event_id, action, target, payload)
    payload["EVIDENCE_PATH"] = ev
    ledger_append({k: payload[k] for k in ("EVENT_ID", "ORDER_ID", "ACTION", "TARGET", "RESULT", "AT")})
    return payload


# ============================ 动作实现 ============================
def act_read_file(target, params, ctx):
    check_read_path(target)
    if not os.path.exists(target):
        return _result(ctx, "READ_FILE", target, None, None,
                       "STOP", note="FILE_NOT_FOUND", BLOCKER="TARGET_PATH_UNAVAILABLE")
    with open(target, "rb") as f:
        b = f.read()
    sha = sha256_bytes(b)
    # R4.1-③ TARGET 审计双字段：记录规范化/实际解析路径，供 Result Gate 核验
    return _result(ctx, "READ_FILE", target, None, sha, "PASS",
                   note=f"size={len(b)}", SIZE=len(b),
                   TARGET_CANONICAL=os.path.realpath(target))


def act_readback_hash(target, params, ctx):
    check_read_path(target)
    if not os.path.exists(target):
        return _result(ctx, "READBACK_HASH", target, None, None,
                       "STOP", note="FILE_NOT_FOUND", BLOCKER="TARGET_PATH_UNAVAILABLE")
    with open(target, "rb") as f:
        b = f.read()
    sha = sha256_bytes(b)
    # R4.1-③ TARGET 审计双字段：记录规范化/实际解析路径，供 Result Gate 核验
    return _result(ctx, "READBACK_HASH", target, None, sha, "PASS",
                   note=f"size={len(b)}", SIZE=len(b),
                   TARGET_CANONICAL=os.path.realpath(target))


def act_patch_own_router(target, params, ctx):
    """只允许改 ~/.wb1/router_rules.json（数据），绝不改 Python 源码。"""
    if _norm(target) != _norm(ROUTER_RULES):
        return _result(ctx, "PATCH_OWN_ROUTER", target, None, None, "STOP",
                       note="ONLY_ROUTER_RULES_PATCHABLE", BLOCKER="TARGET_NOT_ROUTER_RULES")
    if not os.path.exists(ROUTER_RULES):
        return _result(ctx, "PATCH_OWN_ROUTER", target, None, None, "STOP",
                       note="ROUTER_RULES_MISSING", BLOCKER="ROUTER_RULES_ABSENT")
    before_b = open(ROUTER_RULES, "rb").read()
    before = sha256_bytes(before_b)
    rules = json.loads(before_b.decode("utf-8"))
    changes = params.get("changes") or {}
    allowed_keys = ("subtype_map", "executable_subtypes", "kr_gate_subtypes", "notes",
                    "nas_archive_inline_rule")
    applied = {}
    for k, v in changes.items():
        top = k.split(".")[0]
        if top not in allowed_keys:
            return _result(ctx, "PATCH_OWN_ROUTER", target, before, None, "STOP",
                           note=f"KEY_NOT_PATCHABLE: {k}", BLOCKER="PATCH_KEY_NOT_ALLOWED")
        if "." in k:
            sub, leaf = k.split(".", 1)
            node = rules.setdefault(sub, {})
            node[leaf] = v
        else:
            rules[k] = v
        applied[k] = v
    rules["updated_at"] = now_iso()
    rules["updated_by"] = ctx.get("event_id", "unknown")
    new_txt = json.dumps(rules, ensure_ascii=False, indent=2)
    tmp = ROUTER_RULES + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(new_txt)
    os.replace(tmp, ROUTER_RULES)
    after = sha256_bytes(new_txt.encode("utf-8"))
    diff = "\n".join(list(difflib.unified_diff(
        before_b.decode("utf-8").splitlines(), new_txt.splitlines(),
        fromfile="router_rules.before", tofile="router_rules.after", lineterm=""))[:80])
    return _result(ctx, "PATCH_OWN_ROUTER", target, before, after, "PASS",
                   note=f"applied={applied}", DIFF=diff, APPLIED=applied)


def _extract_raw_from_body(body):
    """按 5756255367 纪律：'以下为RAW正文（逐字）：' 之后至尾部元数据之前。"""
    starts = ["以下为RAW正文（逐字）：", "以下为RAW正文（逐字）:", "以下为RAW正文：", "以下为RAW正文:"]
    idx = -1
    for s in starts:
        i = body.find(s)
        if i != -1:
            idx = i + len(s)
            break
    if idx == -1:
        # 兼容 KR原话 形态
        m = re.search(r"KR原话[:：]?\s*\n+", body)
        if m:
            idx = m.end()
            cut = body[idx:]
            lines = [l for l in cut.split("\n")]
            # 到第一个空行结束
            out = []
            for l in lines:
                if l.strip() == "" and out:
                    break
                out.append(l)
            return "\n".join(out).strip("\r\n")
        return None
    rest = body[idx:]
    lines = rest.split("\n")
    tail_keys = ("SOURCE=", "TARGET=", "KR_RELAY=", "END_RAW", "SOURCE:", "TARGET:")
    cut_at = len(lines)
    for i in range(len(lines) - 1, -1, -1):
        st = lines[i].strip()
        if any(st.startswith(k) for k in tail_keys):
            cut_at = i
        elif st.startswith("[") and st.endswith("]") and i > 3:
            # 尾部控制行
            pass
    raw = "\n".join(lines[:cut_at]).strip("\r\n")
    return raw


MANIFEST_COLS = ["ASSET_ID", "TITLE", "SERIES", "WORK_NO", "STATUS", "RAW_PATH",
                 "FINAL_PATH", "RAW_SHA256", "UPDATED_AT", "KR_CONFIRMED"]
MANIFEST_TARGETS = [os.path.join(KR_VAULT, "00_总账", "MANIFEST.csv"),
                    os.path.join(KR_VAULT, "00_总账", "KR原著资产索引.csv")]


def _register_manifest_rows(rows):
    """批量登记：一次读-改-写把【全部行】落进每个目标文件（规避 SMB 逐行追加丢写）。
    rows: [[asset_id,title,series,work_no,status,raw_rel,final_rel,sha,updated_at,kr_confirmed], ...]
    返回 {target: (written_count, 状态)}；逐行回读核验。"""
    norm = [["" if x is None else str(x) for x in r] for r in rows]
    out = {}
    for t in MANIFEST_TARGETS:
        check_write_path(t)
        os.makedirs(os.path.dirname(t), exist_ok=True)
        try:
            with open(t, "r", encoding="utf-8") as f:
                cur = f.read()
        except FileNotFoundError:
            cur = ""
        existing = cur
        new_content = cur
        if not new_content.strip():
            new_content += ",".join(MANIFEST_COLS) + "\n"
        if new_content and not new_content.endswith("\n"):
            new_content += "\n"
        added = []
        for r in norm:
            aid = r[0]
            if aid and f",{aid}," in ("," + existing + ","):
                continue
            if aid and any(ln.startswith(aid + ",") for ln in existing.splitlines()):
                continue
            new_content += ",".join(r) + "\n"
            added.append(aid)
        if not added:
            out[t] = (0, "already registered")
            continue
        tmp = t + ".tmp"
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            f.write(new_content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, t)
        # 回读核验全部新增行确已落盘
        try:
            with open(t, "r", encoding="utf-8") as f:
                back = f.read()
            missing = [a for a in added if not any(ln.startswith(a + ",") for ln in back.splitlines())]
        except Exception:
            out[t] = (0, "READBACK_FAILED")
            continue
        out[t] = (len(added), "OK" if not missing else f"MISSING={missing}")
    return out


def _register_manifest(asset_id, title, series, work_no, status, raw_rel, final_rel, sha, updated_at):
    """单行封装（复用批量实现）。返回 list（兼容旧调用）。"""
    res = _register_manifest_rows([[asset_id, title, series, work_no, status,
                                    raw_rel, final_rel, sha, updated_at, "FALSE"]])
    out = []
    for t, (n, st) in res.items():
        out.append(t if st == "OK" else f"{t} ({st})")
    return out


def _split_doc_blocks(body, max_blocks=8):
    """按 bounded DOC 标记切块（TARGET=THIS_COMMENT inline payload 专用）。
    只认 '===== DOC <n> BEGIN =====' / '===== DOC <n> END =====' 成对标记。
    返回 [(n, block_text), ...]；未成对或超上限 -> 抛 ValueError（诚实 STOP，不猜）。
    块内保留 UTF-8 逐字，不 trim 缩进。"""
    if not isinstance(body, str):
        raise ValueError("BODY_NOT_TEXT")
    begin_re = re.compile(r"^===== DOC (\d+) BEGIN =====\s*$", re.M)
    end_re = re.compile(r"^===== DOC (\d+) END =====\s*$", re.M)
    begins = {int(m.group(1)): m for m in begin_re.finditer(body)}
    ends = {int(m.group(1)): m for m in end_re.finditer(body)}
    if not begins and not ends:
        raise ValueError("NO_DOC_MARKERS")
    if set(begins) != set(ends):
        raise ValueError(f"DOC_MARKER_UNPAIRED begins={sorted(begins)} ends={sorted(ends)}")
    if len(begins) > max_blocks:
        raise ValueError(f"DOC_BLOCKS_OVER_LIMIT count={len(begins)}")
    blocks = []
    for n in sorted(begins):
        bb, be = begins[n], ends[n]
        if be.start() <= bb.end():
            raise ValueError(f"DOC_{n}_END_BEFORE_BEGIN")
        # 块正文 = BEGIN 行末之后 ~ END 行首之前（逐字）
        seg = body[bb.end():be.start()]
        seg = seg.lstrip("\r\n")            # 去掉 BEGIN 后紧邻的换行
        seg = seg.rstrip("\r\n")            # 去掉 END 前紧邻的换行
        if not seg.strip():
            raise ValueError(f"DOC_{n}_EMPTY")
        blocks.append((n, seg))
    return blocks


def _kv_in_block(seg, key):
    """从块内取第一处 KEY=VALUE（仅大写键，行首）。"""
    m = re.search(rf"^{re.escape(key)}=(\S.*)$", seg, re.M)
    return m.group(1).strip() if m else ""


def _sanitize_asset_id(s):
    s = re.sub(r"[^A-Za-z0-9_.-]+", "-", (s or "").strip()).strip("-")
    return s[:80]


def act_nas_archive(target, params, ctx):
    from wb1_case002_nas import guard_archive_root
    guard_archive_root(NAS_ROOT)  # real UNC identity; no local-name fallback
    """source=COMMENT:<id> / THIS_COMMENT / 文件路径；写入 KR原著库 指定子目录；登记 MANIFEST；回读 SHA。

    THIS_COMMENT 扩展（依据 #6 comment 5763433471，数据驱动规则见 router_rules.json
    `nas_archive_inline_rule`）：
      - TARGET=THIS_COMMENT ⇒ 源字节取自【触发本条指令的那个评论正文】本身，绝不回查历史 RAW。
      - 若正文含成对的 '===== DOC <n> BEGIN/END =====' 标记 ⇒ 每块各自独立落盘 + 独立登记 MANIFEST +
        独立回读 SHA256；文件名/记录状态含 RECONSTRUCTED_CURRENT_EDITION 语义。
      - 仅在显式 THIS_COMMENT + bounded DOC markers 下生效；其余情形行为不变。
    """
    # ---- THIS_COMMENT：把触发评论正文作为唯一信源 ----
    if isinstance(target, str) and target.strip().upper() == "THIS_COMMENT":
        body = ctx.get("trigger_body")
        if not isinstance(body, str) or not body.strip():
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note="NO_TRIGGER_BODY", BLOCKER="RAW_SOURCE_UNAVAILABLE")
        try:
            blocks = _split_doc_blocks(body)
        except ValueError as e:
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note=f"DOC_PARSE_FAIL: {e}", BLOCKER="INLINE_DOC_PARSE_FAILED")
        dest_subdir = params.get("dest_subdir") or "90_待归档"
        dest_dir = os.path.join(KR_VAULT, dest_subdir)
        try:
            check_write_path(dest_dir)
        except PermissionError as e:
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note=str(e), BLOCKER="PATH_GUARD")
        os.makedirs(dest_dir, exist_ok=True)
        docs, manifest_rows = [], []
        for n, seg in blocks:
            title = _kv_in_block(seg, "TITLE") or f"DOC-{n}"
            status = _kv_in_block(seg, "STATUS") or params.get("status") or "RECONSTRUCTED_CURRENT_EDITION"
            aid = _sanitize_asset_id(params.get("asset_id_prefix")
                                     and f"{params['asset_id_prefix']}-DOC{n}") or f"NAS-ARCHIVE-{ctx['event_id']}-DOC{n}"
            fname = aid + ".md"
            fpath = os.path.join(dest_dir, fname)
            content = seg.encode("utf-8")
            if os.path.exists(fpath):
                existing = open(fpath, "rb").read()
                if sha256_bytes(existing) == sha256_bytes(content):
                    sha = sha256_bytes(content)
                    rel = fpath.replace(NAS_ROOT, "").lstrip(chr(92))
                    manifest_rows.append([aid, title, params.get("series") or "", f"DOC{n}",
                                          status, rel, "", sha, datetime.date.today().isoformat(), "FALSE"])
                    docs.append({"DOC": n, "TITLE": title, "NAS_PATH": fpath, "SHA256": sha,
                                 "READBACK": "PASS", "STATUS": status,
                                 "NOTE": "IDEMPOTENT_ALREADY_ARCHIVED", "SIZE": len(content)})
                    continue
                fpath = os.path.join(dest_dir, f"{aid}__v{now_iso().replace(':','').replace('-','')}.md")
                fname = os.path.basename(fpath)
            try:
                with open(fpath, "wb") as f:      # 二进制写，规避 CRLF 陷阱
                    f.write(content)
                sha = sha256_bytes(content)
                with open(fpath, "rb") as f:      # 独立回读
                    rb = f.read()
                rb_sha = sha256_bytes(rb)
            except Exception as e:
                return _result(ctx, "NAS_ARCHIVE", target, None, None, "FAIL",
                               note=f"WRITE_OR_READ_FAIL(DOC{n}): {e}", BLOCKER="ARCHIVE_WRITE_FAILED")
            if rb_sha != sha:
                return _result(ctx, "NAS_ARCHIVE", target, None, sha, "FAIL",
                               note=f"READBACK_SHA_MISMATCH(DOC{n}) read={rb_sha}", BLOCKER="READBACK_MISMATCH")
            rel = fpath.replace(NAS_ROOT, "").lstrip(chr(92))
            manifest_rows.append([aid, title, params.get("series") or "", f"DOC{n}",
                                  status, rel, "", sha, datetime.date.today().isoformat(), "FALSE"])
            docs.append({"DOC": n, "TITLE": title, "NAS_PATH": fpath, "SHA256": sha,
                         "READBACK": "PASS", "STATUS": status, "MANIFEST_PATH":
                         os.path.join(KR_VAULT, "00_总账", "MANIFEST.csv"), "SIZE": len(content)})
        if not docs:
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note="NO_DOC_ARCHIVED", BLOCKER="INLINE_DOC_PARSE_FAILED")
        # 全部块写完后再一次性登记（规避 SMB 逐行丢写）
        reg_res = _register_manifest_rows(manifest_rows)
        reg_ok = all(st == "OK" or st.startswith("already") for _, st in reg_res.values())
        registered_all = [f"{t} :: n={n} {st}" for t, (n, st) in reg_res.items()]
        if not reg_ok:
            return _result(ctx, "NAS_ARCHIVE", target, None,
                           ";".join(d["SHA256"] for d in docs), "FAIL",
                           note=f"MANIFEST_REGISTER_INCOMPLETE {reg_res}", BLOCKER="MANIFEST_REGISTER_FAILED",
                           DOCS=docs, DOC_COUNT=len(docs), REGISTERED=registered_all)
        return _result(ctx, "NAS_ARCHIVE", target, None,
                       ";".join(d["SHA256"] for d in docs), "PASS",
                       note=f"inline DOC blocks archived, count={len(docs)}",
                       DOCS=docs, DOC_COUNT=len(docs),
                       NAS_PATH=docs[0]["NAS_PATH"], RAW_VERBATIM="PASS", INDEXED="PASS",
                       REGISTERED=registered_all, READBACK="PASS",
                       MANIFEST_PATH=os.path.join(KR_VAULT, "00_总账", "MANIFEST.csv"))

    dest_subdir = params.get("dest_subdir") or "90_待归档"
    asset_id = params.get("asset_id") or f"AUTO-{ctx['event_id']}"
    title = params.get("title") or asset_id
    series = params.get("series", "")
    work_no = params.get("work_no", "")
    status = params.get("status", "RAW_ARCHIVED_VERBATIM")

    raw = None
    src_desc = target
    if target.startswith("COMMENT:"):
        cid = target.split(":", 1)[1].strip()
        body = ctx.get("fetch_comment_body")
        if not callable(body):
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note="NO_COMMENT_FETCHER", BLOCKER="INTERNAL_NO_FETCHER")
        cb = body(int(cid))
        if not cb:
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note="COMMENT_FETCH_FAILED", BLOCKER="RAW_SOURCE_UNAVAILABLE")
        raw = _extract_raw_from_body(cb)
        if not raw:
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note="RAW_MARKER_NOT_FOUND_IN_COMMENT", BLOCKER="RAW_SOURCE_UNAVAILABLE")
    else:
        if not os.path.exists(target):
            return _result(ctx, "NAS_ARCHIVE", target, None, None, "STOP",
                           note="SOURCE_NOT_FOUND", BLOCKER="RAW_SOURCE_UNAVAILABLE")
        check_read_path(target)
        raw = open(target, "rb").read()

    dest_dir = os.path.join(KR_VAULT, dest_subdir)
    check_write_path(dest_dir)
    os.makedirs(dest_dir, exist_ok=True)
    fname = asset_id + (".md" if isinstance(raw, str) else os.path.splitext(target)[1])
    fpath = os.path.join(dest_dir, fname)
    # 不覆盖同名 RAW：冲突则版本化
    if os.path.exists(fpath):
        existing = open(fpath, "rb").read()
        newb = raw.encode("utf-8") if isinstance(raw, str) else raw
        if sha256_bytes(existing) == sha256_bytes(newb):
            sha = sha256_bytes(newb)
            return _result(ctx, "NAS_ARCHIVE", target, None, sha, "PASS",
                           note="IDEMPOTENT_ALREADY_ARCHIVED", NAS_PATH=fpath,
                           RAW_PATH=fpath, DEST=fpath)
        fpath = os.path.join(dest_dir, f"{asset_id}__v{now_iso().replace(':','').replace('-','')}.md")

    content = raw if isinstance(raw, bytes) else raw.encode("utf-8")
    with open(fpath, "wb") as f:      # 二进制写，规避 CRLF 陷阱
        f.write(content)
    sha = sha256_bytes(content)
    with open(fpath, "rb") as f:      # 回读
        rb = f.read()
    rb_sha = sha256_bytes(rb)
    if rb_sha != sha:
        return _result(ctx, "NAS_ARCHIVE", target, None, sha, "FAIL",
                       note=f"READBACK_SHA_MISMATCH read={rb_sha}", BLOCKER="READBACK_MISMATCH")
    rel = fpath.replace(NAS_ROOT, "").lstrip(chr(92))
    reg = _register_manifest(asset_id, title, series, work_no, status, rel, "", sha,
                             datetime.date.today().isoformat())
    return _result(ctx, "NAS_ARCHIVE", target, None, sha, "PASS",
                   note=f"verbatim archived, size={len(content)}", NAS_PATH=fpath,
                   RAW_PATH=fpath, MANIFEST_PATH=os.path.join(KR_VAULT, "00_总账", "MANIFEST.csv"),
                   READBACK="PASS", RAW_VERBATIM="PASS", INDEXED="PASS", REGISTERED=reg,
                   SIZE=len(content))


def act_reprocess_comment(target, params, ctx):
    """重摄取指定 Issue #6 评论（仅 #6）。委托 heartbeat 的 dispatch（reprocess 模式）。"""
    cid = str(target).strip()
    if not cid.isdigit():
        return _result(ctx, "REPROCESS_COMMENT", target, None, None, "STOP",
                       note="TARGET_NOT_COMMENT_ID", BLOCKER="BAD_TARGET")
    fn = ctx.get("reprocess")
    if not callable(fn):
        return _result(ctx, "REPROCESS_COMMENT", target, None, None, "STOP",
                       note="NO_REPROCESS_HOOK", BLOCKER="INTERNAL_NO_REPROCESS")
    res = fn(int(cid))
    return _result(ctx, "REPROCESS_COMMENT", target, None, None,
                   res.get("RESULT", "UNKNOWN"), note=res.get("NOTE", ""),
                   SOURCE_COMMENT_ID=int(cid), ACK_COMMENT_ID=res.get("ACK_COMMENT_ID"),
                   RESULT_COMMENT_ID=res.get("RESULT_COMMENT_ID"),
                   CLASS=res.get("CLASS"), DETAIL=res)


DISPATCH = {
    "READ_FILE": act_read_file,
    "READBACK_HASH": act_readback_hash,
    "PATCH_OWN_ROUTER": act_patch_own_router,
    "NAS_ARCHIVE": act_nas_archive,
    "REPROCESS_COMMENT": act_reprocess_comment,
}


def run(action, target, params, ctx):
    if action not in BRIDGE_ACTIONS:
        return _result(ctx, action, target, None, None, "STOP",
                       note=f"ACTION_NOT_WHITELISTED", BLOCKER="ACTION_NOT_IN_WHITELIST",
                       ALLOWED=BRIDGE_ACTIONS)
    try:
        return DISPATCH[action](target, params or {}, ctx)
    except PermissionError as e:
        return _result(ctx, action, target, None, None, "STOP",
                       note=str(e), BLOCKER="PATH_GUARD")
    except Exception as e:
        return _result(ctx, action, target, None, None, "FAIL",
                       note=f"EXEC_ERROR: {e}", BLOCKER="BRIDGE_EXCEPTION")


if __name__ == "__main__":
    print("local_exec_bridge V0.1 :: whitelist =", BRIDGE_ACTIONS)


def case002_archive_prepared(documents):
    """Internal adapter only; not added to remote BRIDGE_ACTIONS/DISPATCH."""
    from wb1_case002_nas import write_prepared
    return write_prepared(documents)
