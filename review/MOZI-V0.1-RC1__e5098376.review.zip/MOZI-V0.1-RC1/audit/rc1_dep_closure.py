import os, ast, hashlib

BUILD = r"C:\Users\59605\.wb1\build\MOZI-V0.1-RC1"
SEARCH_DIRS = [BUILD, r"C:\Users\59605\.wb1", r"C:\Users\59605\.wb1\mozi_v0.1\src", r"C:\Users\59605"]

SEED_FILES = [
    os.path.join(BUILD, "wb1_local_exec_bridge.py"),
    os.path.join(BUILD, "src", "mozi.py"),
    os.path.join(BUILD, "src", "compiler.py"),
    os.path.join(BUILD, "src", "contract.py"),
    os.path.join(BUILD, "src", "executor.py"),
    os.path.join(BUILD, "src", "result_gate.py"),
    os.path.join(BUILD, "src", "ledger.py"),
]

STDLIB = set("""os sys json re hashlib datetime difflib argparse logging time random
string io base64 struct subprocess shutil glob pathlib inspect typing collections
itertools functools warnings traceback unittest urllib socket csv tempfile signal
threading queue concurrent copy math enum dataclasses contextlib abc weakref hmac""".split())

def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()

def resolve(mod):
    base = mod.split('.')[0]
    for d in SEARCH_DIRS:
        c = os.path.join(d, base + ".py")
        if os.path.exists(c):
            return c
    return None

# recursive closure over local (non-stdlib, non-RC1-internal) imports
visited = {}   # module name -> path
worklist = list(SEED_FILES)
rc1_internal = {"mozi","compiler","contract","executor","result_gate","ledger","wb1_local_exec_bridge"}

while worklist:
    f = worklist.pop()
    if not os.path.exists(f):
        continue
    try:
        tree = ast.parse(open(f, encoding="utf-8", errors="replace").read())
    except Exception as e:
        print("PARSE_ERR", f, e); continue
    for node in ast.walk(tree):
        mods = []
        if isinstance(node, ast.Import):
            mods = [a.name.split('.')[0] for a in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module:
            mods = [node.module.split('.')[0]]
        for m in mods:
            if m in STDLIB or m in rc1_internal:
                continue
            if m in visited:
                continue
            rp = resolve(m)
            if rp:
                visited[m] = rp
                worklist.append(rp)

print("=== RECURSIVE LOCAL CODE DEPENDENCY CLOSURE (beyond 8 RC1 components) ===")
for m, p in sorted(visited.items()):
    print(f"{m:28s} {os.path.getsize(p):8d}B  sha={sha(p)[:16]}..  {p}")

# Also: which RC1 component pulls each
print("\n=== Direct importers ===")
for comp in SEED_FILES:
    try:
        tree = ast.parse(open(comp, encoding="utf-8", errors="replace").read())
    except: continue
    names=set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(a.name.split('.')[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.add(node.module.split('.')[0])
    pulled = [m for m in names if m in visited]
    if pulled:
        print(f"  {os.path.basename(comp)} -> {pulled}")
