import os, ast, json, hashlib, re, sys

BUILD = r"C:\Users\59605\.wb1\build\MOZI-V0.1-RC1"
REAL_SRC = r"C:\Users\59605\.wb1\mozi_v0.1\src"
REAL_BRIDGE = r"C:\Users\59605\.wb1\wb1_local_exec_bridge.py"
REAL_CONTRACT = r"C:\Users\59605\.wb1\mozi_v0.1\contract_v0.1.json"
SEARCH_DIRS = [BUILD, REAL_SRC, r"C:\Users\59605\.wb1", r"C:\Users\59605"]

# RC1 8 registered components (build dir copies)
COMPONENTS = {
    "contract_v0.1.json": os.path.join(BUILD, "contract_v0.1.json"),
    "wb1_local_exec_bridge.py": os.path.join(BUILD, "wb1_local_exec_bridge.py"),
    "src/mozi.py": os.path.join(BUILD, "src", "mozi.py"),
    "src/compiler.py": os.path.join(BUILD, "src", "compiler.py"),
    "src/contract.py": os.path.join(BUILD, "src", "contract.py"),
    "src/executor.py": os.path.join(BUILD, "src", "executor.py"),
    "src/result_gate.py": os.path.join(BUILD, "src", "result_gate.py"),
    "src/ledger.py": os.path.join(BUILD, "src", "ledger.py"),
}

STDLIB = set("""os sys json re hashlib datetime difflib argparse logging time
random string io base64 struct subprocess shutil glob pathlib inspect
typing collections itertools functools warnings traceback unittest
urllib socket csv tempfile signal threading queue concurrent copy math
enum dataclasses contextlib abc weakref""".split())

def sha(p):
    try:
        return hashlib.sha256(open(p,'rb').read()).hexdigest()
    except Exception as e:
        return "ERR:"+str(e)

def resolve_local(modname):
    # strip leading dots
    base = modname.split('.')[0]
    for d in SEARCH_DIRS:
        cand = os.path.join(d, base + ".py")
        if os.path.exists(cand):
            return cand
    return None

report = {"imports": {}, "local_modules_found": {}, "external_refs": {}}
PY_FILES = [p for p in COMPONENTS.values() if p.endswith(".py")]

for name, path in COMPONENTS.items():
    if not path.endswith(".py"):
        continue
    src = open(path, encoding="utf-8", errors="replace").read()
    mods = set()
    try:
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    mods.add(a.name.split('.')[0])
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    mods.add(node.module.split('.')[0])
    except Exception as e:
        mods.add("PARSE_ERR:"+str(e))
    report["imports"][name] = sorted(mods)

# resolve local modules
allmods = set()
for m in report["imports"].values():
    allmods.update(m)
for mod in sorted(allmods):
    if mod in STDLIB or mod.startswith("PARSE_ERR"):
        continue
    if mod in ("mozi","compiler","contract","executor","result_gate","ledger"):
        continue  # these are RC1 internal src modules (already registered)
    resolved = resolve_local(mod)
    if resolved:
        report["local_modules_found"][mod] = {"path": resolved, "sha256": sha(resolved), "size": os.path.getsize(resolved)}
    else:
        report["local_modules_found"][mod] = {"path": None, "note": "NOT_RESOLVED_IN_SEARCH_DIRS"}

# text scan for external refs
PATTERNS = {
    "env_var": r"os\.(environ|getenv)\s*\[?\s*['\"]([\w]+)['\"]",
    "open_call": r"\bopen\s*\(",
    "subprocess": r"subprocess\.(Popen|run|call|check_output|check_call)",
    "json_load": r"json\.load",
    "yaml": r"import yaml|yaml\.load",
    "path_abs": r"(C:\\\\Users|\\\\\\\\192\.168|/nas/|AISALEOS|router_rules|lark|github_pat|\.wb1)",
}
for name, path in COMPONENTS.items():
    if not path.endswith(".py"):
        continue
    src = open(path, encoding="utf-8", errors="replace").read()
    found = {}
    for k, pat in PATTERNS.items():
        ms = re.findall(pat, src)
        if ms:
            found[k] = list(set([str(x) for x in ms]))
    if found:
        report["external_refs"][name] = found

print(json.dumps(report, indent=2, ensure_ascii=False))
