"""Append-only, fsynced CASE-002 execution evidence; no payload or credentials."""
from contextlib import contextmanager
from contextvars import ContextVar
import ctypes
from ctypes import wintypes
import datetime
import functools
import getpass
import json
import os
from pathlib import Path
import re
import sys
import traceback
import uuid

_active = ContextVar('case002_trace', default=None)


def scrub(value):
    text = str(value)
    text = re.sub(r'(?i)(?:gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+)', '[REDACTED_TOKEN]', text)
    text = re.sub(r'(?i)(Bearer\s+)\S+', r'\1[REDACTED]', text)
    return text


def identity():
    account = getpass.getuser()
    method = 'getpass_fallback'
    if os.name == 'nt':
        try:
            lib = ctypes.WinDLL('secur32', use_last_error=True)
            fn = lib.GetUserNameExW
            fn.argtypes = [ctypes.c_int, wintypes.LPWSTR, ctypes.POINTER(wintypes.ULONG)]
            fn.restype = wintypes.BOOLEAN
            buf = ctypes.create_unicode_buffer(1024)
            size = wintypes.ULONG(len(buf))
            if fn(2, buf, ctypes.byref(size)):
                account, method = buf.value, 'GetUserNameExW_NameSamCompatible'
        except Exception:
            pass
    return {'account': account, 'identity_method': method, 'pid': os.getpid(),
            'executable': sys.executable, 'host': os.environ.get('COMPUTERNAME')}


@contextmanager
def session(wb1, entry_path):
    directory = Path(wb1) / 'exec_results'
    directory.mkdir(exist_ok=True)
    run = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + str(os.getpid()) + '-' + uuid.uuid4().hex
    path = directory / ('CASE002-' + run + '.jsonl')
    with open(path, 'x', encoding='utf-8', newline='\n') as stream:
        token = _active.set({'stream': stream, 'run': run})
        try:
            event('RUN_START', entry_path=entry_path, **identity())
            yield
        finally:
            _active.reset(token)


def event(kind, **fields):
    active = _active.get()
    if active is None:
        return
    data = {'time': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'run_id': active['run'], 'event': kind, **fields}
    def clean(value):
        if isinstance(value, str):
            return scrub(value)
        if isinstance(value, dict):
            return {k: clean(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [clean(v) for v in value]
        return value
    encoded = json.dumps(clean(data), ensure_ascii=True, default=str)
    active['stream'].write(encoded + '\n')
    active['stream'].flush()
    os.fsync(active['stream'].fileno())


@contextmanager
def stage(name):
    event('STAGE_START', stage=name)
    try:
        yield
    except BaseException as error:
        event('STAGE_FAIL', stage=name, exception_type=type(error).__name__,
              exception_module=type(error).__module__, message=str(error),
              errno=getattr(error, 'errno', None), winerror=getattr(error, 'winerror', None),
              filename=getattr(error, 'filename', None), filename2=getattr(error, 'filename2', None),
              traceback=''.join(traceback.TracebackException.from_exception(error, capture_locals=False).format(chain=True)))
        raise
    else:
        event('STAGE_OK', stage=name)


def traced(name):
    def wrap(fn):
        @functools.wraps(fn)
        def call(*args, **kwargs):
            with stage(name):
                return fn(*args, **kwargs)
        return call
    return wrap
